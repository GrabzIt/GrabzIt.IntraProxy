GrabzIt IntraProxy Installation Instructions
=============================================

- Ensure Java 1.6+ is installed
- Extract these files into a empty directory
- Navigate to the bin directory
- Execute installDaemon.sh
- Execute startDaemon.sh
- Open a browser and navigate to http://localhost:10000/grabzit://dashboard.html for further instructions.